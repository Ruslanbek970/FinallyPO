package com.example.booking.Enum;

public enum CancellationPolicy {
    FREE_CANCELLATION,
    NO_REFUND,
    PARTIAL
}
