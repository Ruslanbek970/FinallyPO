package com.example.booking.Enum;

public enum PaymentStatus {
    INITIATED,
    PAID,
    FAILED,
    REFUNDED
}
