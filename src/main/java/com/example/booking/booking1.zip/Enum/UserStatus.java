package com.example.booking.Enum;

public enum UserStatus {
    ACTIVE,
    BLOCKED
}
