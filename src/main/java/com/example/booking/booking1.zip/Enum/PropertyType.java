package com.example.booking.Enum;

public enum PropertyType {
    HOTEL,
    APARTMENT
}
