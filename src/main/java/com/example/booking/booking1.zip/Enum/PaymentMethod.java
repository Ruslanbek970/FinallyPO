package com.example.booking.Enum;

public enum PaymentMethod {
    CARD,
    CASH,
    TRANSFER
}
