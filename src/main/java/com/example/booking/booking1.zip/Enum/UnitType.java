package com.example.booking.Enum;

public enum UnitType {
    ROOM,
    APARTMENT,
    STUDIO
}
