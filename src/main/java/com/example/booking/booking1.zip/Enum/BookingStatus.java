package com.example.booking.Enum;

public enum BookingStatus {
    CREATED,
    CONFIRMED,
    CANCELLED,
    COMPLETED
}
