package com.example.booking.Enum;

public enum ReviewStatus {
    PENDING,
    APPROVED,
    REJECTED
}
